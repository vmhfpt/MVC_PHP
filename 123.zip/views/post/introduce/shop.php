<?php $this->loadView('post/Layout/header') ?>
<?php $this->loadView('post/Layout/nav') ?>

<section class="app-bread-crumb container-fluid">
            <div class="container">
              <ul >
                <li ><a href="" >Trang chủ</a> /</li>
                <li ><a href="" >Cửa hàng</a></li>
              </ul>
            </div>
          </section>

      <section class="app-shop container-fluid">
          <div class="container">
            <div class="app-shop-title">
                <span class="">HỆ THỐNG CỬA HÀNG DI ĐỘNG THÔNG MINH</span>
            </div>
             <div class="row">
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - CẦU GIẤY, HÀ NỘI</h3>
                         <ul>
                            <li>137 Xuân Thủy, Cầu Giấy, Hà Nội</li>
                            <li>0946922268</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2022/03/original/137xuanthuy_1646494131.jpg" alt="" class="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - ĐỐNG ĐA, HÀ NỘI</h3>
                         <ul>
                            <li>119 Thái Thịnh Đống Đa, Hà Nội</li>
                            <li>096611995</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2022/03/original/119thaithinh_1646493609.jpg" alt="" class="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - TP HẢI PHÒNG</h3>
                         <ul>
                            <li>35B Chợ Con, gần Hồ Bạch Đằng, TP Hải Phòng</li>
                            <li>0899965566</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2022/03/original/35chocon_1646494559.jpg" alt="" class="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - TP HẢI PHÒNG</h3>
                         <ul>
                            <li>12 Điện Biên Phủ Hải Phòng</li>
                            <li>0916551212</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2022/03/original/12_dienbienphu_1646494634.jpg" alt="" class="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - ĐÀ NẴNG</h3>
                         <ul>
                            <li>65 Hàm Nghi, quận Thanh Khê, Đà Nẵng</li>
                            <li>0899976655</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2022/03/original/65thanhkhejpg_1646495112.jpg" alt="" class="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - ĐÀ NẴNG</h3>
                         <ul>
                            <li>65 Hải Phòng, Quận Hải Châu, Đà Nẵng</li>
                            <li>0946922268</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2022/07/original/haiphong2jpg_1656929961.jpg" alt="" class="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - Cần Thơ</h3>
                         <ul>
                            <li>137 Xuân Thủy, Cầu Giấy, Hà Nội</li>
                            <li>0946922268</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2023/05/original/ctho_1683735048.jpg" alt="" class="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 ">
                    <div class="app-shop__item">
                         <h3 class="">DI ĐỘNG THÔNG MINH - TP HỒ CHÍ MINH</h3>
                         <ul>
                            <li>137 Xuân Thủy, Cầu Giấy, Hà Nội</li>
                            <li>0946922268</li>
                         </ul>

                         <img src="https://didongthongminh.vn/images/address/2022/03/original/f81266631363dc3d8572_1646992659.jpg" alt="" class="">
                    </div>
                </div>
             </div>
          </div>
      </section>
<?php $this->loadView('post/Layout/top') ?>
<?php $this->loadView('post/Layout/footer') ?>