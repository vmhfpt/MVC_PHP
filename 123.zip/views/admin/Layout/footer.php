
</div>

<footer class="main-footer">
            <div class="float-right d-none d-sm-block">
                <b>Version</b> 3.2.0
            </div>
            <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
        </footer>

       

    </div>


    <script src="<?=SITE_URL_ADMIN?>/plugins/jquery/jquery.min.js"></script>

    <script src="<?=SITE_URL_ADMIN?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="<?=SITE_URL_ADMIN?>/dist/js/adminlte.min.js?v=3.2.0"></script>

    <script src="<?=SITE_URL_ADMIN?>/dist/js/demo.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/select2/js/select2.full.min.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/moment/moment.min.js"></script>
<script src="<?=SITE_URL_ADMIN?>/plugins/inputmask/jquery.inputmask.min.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/daterangepicker/daterangepicker.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/bs-stepper/js/bs-stepper.min.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/dropzone/min/dropzone.min.js"></script>


<script src="<?=SITE_URL_ADMIN?>/plugins/flot/jquery.flot.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/flot/plugins/jquery.flot.resize.js"></script>

<script src="<?=SITE_URL_ADMIN?>/plugins/flot/plugins/jquery.flot.pie.js"></script>


</body>

</html>