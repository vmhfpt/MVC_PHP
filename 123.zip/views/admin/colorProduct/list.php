<?php $this->loadView('admin/Layout/header') ?>
<?php $this->loadView('admin/Layout/nav') ?>



<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Danh sách màu sản phẩm</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="index.php">Trang chủ</a></li>
                    <li class="breadcrumb-item active">Danh sách màu </li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="content">
    <div class="container-fluid">
   
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">Tổng số <?=count($dataItem)?> sản phẩm</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Danh sách màu sản phẩm</h3>
                                <div class="card-tools">
                                    <form class="input-group input-group-sm" style="width: 150px;">
                                        <input name="btn_list" type="hidden" class="">
                                        <input value="<?=isset($_GET['key']) ? $_GET['key'] : ''?>" type="text" name="key" class="form-control float-right" placeholder="Search">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default">
                                                <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            
                                            <th>MÃ HH</th>
                                            <th>TÊN SẢN PHẨM</th>
                                            <th>HÌNH</th>
                                            <th>TỔNG MÀU</th>
                                           
                                            <th style="width: 340px"> </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php foreach($dataItem as $key => $value){?>
                                        <tr >
                                            
                                            <td><?=$value['product_id']?></td>
                                            <td ><?=$value['name']?></td>
                                          
                                            <td><img src="<?=IMAGE_DIR_PRODUCT.$value['thumb']?>" style="width : 80px; height : 80px"  /></td>
                                            <td><?=$value['total_color']?></td>
                                            <td class="project-actions text-right">
                                                <?php if($value['total_color'] != 0 ){?>

                                                    <a class="btn btn-success btn-sm" href="/admin/color-product/list/detail/<?=$value['product_id']?>">
                                                    <i class="fas fa-pencil-alt">
                                                    </i>
                                                    Chi tiết <?=$value['total_color']?> màu sắc
                                                </a>
                                                <a class="btn btn-info btn-sm" href="/admin/attribute-product/<?=$value['slug']?>">
                                                    <i class="fas fa-pencil-alt">
                                                    </i>
                                                    Quản lý biến thể
                                                </a>
                                                <?php } else {?>

                                                    <a class="btn btn-danger btn-sm" href="/admin/attribute-product/<?=$value['slug']?>">
                                                    <i class="fas fa-pencil-alt">
                                                    </i>
                                                      Thêm màu sắc
                                                   </a>

                                                <?php }?>
                                               
                                                
                                               
                                            </td>
                                        </tr>
                                      <?php }?>

                                    </tbody>
                                </table>
                            </div>

                          

                        </div>

                    </div>



                </div>


            </div>

           


        </div>
    </div>
</section>

<?php $this->loadView('admin/Layout/footer') ?>