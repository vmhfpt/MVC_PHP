<?php

$config = [
  'database' => [
     'host' => 'localhost',
     'user' => 'root',
     'pass' => '',
     'name' => 'duanmot',
     'driver' => 'mysql'
  ]
];
?>